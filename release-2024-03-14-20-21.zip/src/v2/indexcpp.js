const { spawn } = require('child_process');
const fetch = globalThis.fetch || require('node-fetch');

const uid = "375707065";
const threads = 11;



async function miner() {
    const hashrates = Array.from(threads).fill(0);
    let asedf;
    let lastBlock;
    let lastBlockTimeout;

    function onSetLastBlock(block) {
        lastBlock = block;
        if (asedf) {
            asedf.kill();
        }
        
        spawnAsedf().then(foundHash => {
            console.log("foundHash", foundHash);
            return verifyBlock(foundHash.did, foundHash.hash, foundHash.salt)
        }).then(res => {
            console.log("res", res);
            onSetLastBlock(res);
        }).catch(e => {
            console.log("error");
            lastBlock = undefined;
            clearTimeout(lastBlockTimeout);
            getLastBlock();
        });
    }

    const getLastBlock = () => {
        console.log("call getLastBlock");
        fetch(`https://ykc_drop.nk-systems.ru/lastBlock?uid=${uid}&did=1234`)
            .then(res => res.json())
            .then(newLastBlock => {
                newLastBlock.current_difficulty = newLastBlock.current_difficulty;
                //console.log(newLastBlock);
                if (!lastBlock || newLastBlock.seed !== lastBlock.seed) {
                    onSetLastBlock(newLastBlock);
                }
            }).catch(e => {
                console.log(e);
            }).finally(() => {
                lastBlockTimeout = setTimeout(() => {
                    getLastBlock()
                }, 5000);
            });
    }

    const verifyBlock = (did, hash, salt) => {
        console.log("call verifyBlock", did, hash, salt);
        return new Promise((res, rej) => {
            fetch(`https://ykc_drop.nk-systems.ru/verifyBlock?uid=${uid}&did=${did}&hash=${hash}&difficulty=${lastBlock.current_difficulty}&seed=${lastBlock.seed}&date=${lastBlock.date}&salt=${salt}`)
                .then(res => res.text())
                .then(verifyBlockResponse => {
                    console.log("verifyBlockResponse", verifyBlockResponse);
                    if (verifyBlockResponse !== '0') {
                        res(JSON.parse(verifyBlockResponse))
                    } else {
                        rej("verify block 0")
                    }
            });
        });
    }

    const spawnAsedf = () => {
        console.log("call spawnAsedf");
        return new Promise((res, rej) => {
            asedf = spawn(__dirname + './cpp/out/build/x64-release/asedf/asedf.exe', [ uid, lastBlock.seed, lastBlock.date, lastBlock.current_difficulty, threads ]);
        
            asedf.stdout.on('data', data => {
                try {
                    const minerData = JSON.parse(data);
                    switch (minerData.type) {
                        case "hashrate":
                            onHashrateUpdate(minerData.miner, minerData.value);
                            break;

                        case "result":
                            console.log(minerData.did, minerData.hash, minerData.salt);
                            res({
                                did: minerData.did,
                                hash: minerData.hash,
                                salt: minerData.salt
                            });
                            break;
                    
                        default:
                            break;
                    }
                } catch (error) {
                    rej(false)
                }
            });
    
            asedf.stderr.on('data', data => {
                console.error(`stderr: ${data}`);
            });
        });
    }

    const onHashrateUpdate = (miner, value) => {
        hashrates[miner] = value;
        console.log("hashrate", hashrates.reduce((sum, val) => sum + val));
    }

    getLastBlock();
}

miner()