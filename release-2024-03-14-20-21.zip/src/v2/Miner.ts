import { spawn, type ChildProcessWithoutNullStreams } from "child_process";

const executablePatches: Partial<Record<NodeJS.Platform, string>> = {
    win32: __dirname + "/../../cpp/out/build/x64-release/asedf/asedf.exe",
    linux: __dirname + "/../../cpp/out/build/linux-release/asedf/asedf",
};

export type Block = {
    seed: string;
    date: number;
    current_difficulty: number;
};

type AsedfUpdateHashrate = {
    type: "hashrate";
    miner: number;
    value: number;
};

type AsedfUpdateResult = {
    type: "result";
    did: number;
    salt: number;
    hash: string;
};

type AsedfUpdate = AsedfUpdateHashrate | AsedfUpdateResult;

export class Miner {
    private uid: string;
    private asedf: ChildProcessWithoutNullStreams | undefined;
    private threads: number;
    private lastBlock: Block | undefined;
    private executablePatch: string;
    hashrate: number = 0;
    hashrates: number[];

    constructor(uid: string, threads: number) {
        const os = process.platform;
        const executablePatch = executablePatches[os];

        if (!executablePatch) {
            throw new Error("os not supported");
        }

        this.executablePatch = executablePatch;
        this.threads = threads;
        this.hashrates = new Array(threads).fill(0);
        this.uid = uid;
    }

    start() {
        if (this.lastBlock) {
            this.asedf = spawn(this.executablePatch, [
                this.uid,
                this.lastBlock.seed,
                this.lastBlock.date.toString(),
                this.lastBlock.current_difficulty.toString(),
                this.threads.toString(),
            ]);

            this.asedf.stdout.on("data", (data: Buffer) => {
                try {
                    const minerData: AsedfUpdate = JSON.parse(data.toString());
                    this.onAsedfUptate(minerData);
                } catch (error) {
                    console.log("asedf.stdout error", error);
                }
            });

            this.asedf.stderr.on("data", (data) => {
                console.error(`stderr: ${data}`);
            });
        }
    }

    onAsedfUptate(data: AsedfUpdate) {
        switch (data.type) {
            case "hashrate":
                this.onHashrateUpdate(data.miner, data.value);
                break;

            case "result":
                console.log(data.did, data.hash, data.salt);
                this.onResult(data.did, data.salt, data.hash);
                break;

            default:
                break;
        }
    }

    onHashrateUpdate(miner: number, value: number) {
        this.hashrates[miner] = value;
        console.log("hashrate", this.hashrates.reduce((sum, val) => sum + val));
    }

    async onResult(did: number, salt: number, hash: string) {
        console.log("onResult not implemented", did, salt, hash);
    }

    setLastblock(block: Block) {
        this.lastBlock = block;
        if (this.asedf) {
            this.asedf.kill();
        }

        this.start();
    }
}
