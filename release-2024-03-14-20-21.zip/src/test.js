const crypto = require("crypto");

const hash = crypto.createHash("sha256").update("asdassf").digest("hex");

let count = 0;
for (let hashIter = 0; hashIter < hash.length; ++hashIter) {
    if (hash[hashIter] === '0') count++;
}

console.log(count);