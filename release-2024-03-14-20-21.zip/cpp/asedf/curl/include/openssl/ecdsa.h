/* $OpenBSD: ecdsa.h,v 1.20 2023/07/28 09:16:17 tb Exp $ */
/*
 * Public domain.
 */

#include <openssl/ec.h>
