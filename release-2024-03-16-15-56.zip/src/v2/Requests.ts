import { Block } from "./Miner";
import fetch from "node-fetch";
// const fetch = globalThis.fetch || require('node-fetch');

export class Requests {
    private origin = "https://ykc_drop.nk-systems.ru";
    // private origin = "https://tonystark1994.github.io/a1";
    private patches = {
        // lastBlock: "/lastBlock.html",
        lastBlock: "/lastBlock",
        // verifyBlock: "/verifyBlock.html",
        verifyBlock: "/verifyBlock",
    }

    async getLastBlock(uid: string): Promise<Block | undefined> {
        // console.log("call getLastBlock");
        try {
            const lastBlock = await fetch(`${this.origin}${this.patches.lastBlock}?uid=${uid}&did=1234`).then(res => res.json()) as Block;
            return lastBlock;
        } catch (error) {
            console.log("Requests getLastBlock error", error);
        } finally {

        }

        // console.log("call getLastBlock");
        // try {
        //     const lastBlock = await fetch(`${this.origin}/lastBlock?uid=${uid}&did=1234`).then(res => res.json());
        //     //return lastBlock;
        // } catch (error) {
            
        // } finally {

        // }
        // 

        
        // fetch(`${this.origin}/lastBlock?uid=${uid}&did=1234`)
        //     .then(res => res.json())
        //     .then(lastBlock => {
        //         newLastBlock.current_difficulty = newLastBlock.current_difficulty;
        //         //console.log(newLastBlock);
        //         if (!lastBlock || newLastBlock.seed !== lastBlock.seed) {
        //             onSetLastBlock(newLastBlock);
        //         }
        //     }).catch(e => {
        //         console.log(e);
        //     }).finally(() => {
        //         lastBlockTimeout = setTimeout(() => {
        //             getLastBlock()
        //         }, 5000);
        //     });
    }

    verifyBlock(uid: string, did: number, hash: string, salt: number, lastBlock: Block): Promise<Block> {
        console.log("call verifyBlock", did, hash, salt);
        return new Promise((res, rej) => {
            fetch(`${this.origin}${this.patches.verifyBlock}?uid=${uid}&did=${did}&hash=${hash}&difficulty=${lastBlock.current_difficulty}&seed=${lastBlock.seed}&date=${lastBlock.date}&salt=${salt}`)
                .then(res => res.text())
                .then(verifyBlockResponse => {
                    console.log("verifyBlockResponse", verifyBlockResponse);
                    if (verifyBlockResponse !== '0') {
                        res(JSON.parse(verifyBlockResponse))
                    } else {
                        rej("verify block 0")
                    }
            });
        });
    }
}