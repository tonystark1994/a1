import { Block, Miner } from "./Miner";
import { Requests } from "./Requests";

const uid = "375707065";
const threads = 11;

const timeoutByDifficulty: Record<number, number> = {
    18: 3000,
    19: 4000,
    20: 5000,
    21: 7000,
    22: 15000,
}

const miner = new Miner(uid, threads);
const requests = new Requests();

let currentBlock: Block;
let lastBlockTimeout: NodeJS.Timeout;

miner.onResult = async (did: number, salt: number, hash: string) => {
    try {
        const newBlock = await requests.verifyBlock(uid, did, hash, salt, currentBlock);
        currentBlock = newBlock;
        console.log(new Date().toLocaleString(), "verifyBlockRes", currentBlock);
        miner.setLastblock(currentBlock);
    } finally {
        clearTimeout(lastBlockTimeout);
        checkLastBlock();
    }
}

async function checkLastBlock() {
    const lastBlock = await requests.getLastBlock(uid);
    
    if (lastBlock) {
        if (currentBlock?.seed !== lastBlock.seed) {
            currentBlock = lastBlock;
            miner.setLastblock(currentBlock);
        }
    }

    lastBlockTimeout = setTimeout(() => {
        checkLastBlock()
    }, timeoutByDifficulty[currentBlock?.current_difficulty] ?? 5000);
}

checkLastBlock();