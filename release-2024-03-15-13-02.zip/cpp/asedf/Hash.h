#ifndef Hash_H
#define Hash_H

#include <string>

using namespace std;

struct Hash {
	string did;
	long salt;
	string hash;
};

#endif